# THESE ARE THE ROUTES FOR MY APP! (LIKE IN FLASK)

# We must import path here
from django.urls import path 

# We must import our views file from soup/views.py  
from . import views

# Now we can attach each route to the specified route in our views.py
urlpatterns = [
    path('', views.root),
    path('blogs', views.index),
    path('blogs/new', views.new),
    path('blogs/create', views.create),
    path('blogs/<int:number>', views.show),
    path('blogs/<int:number>/edit', views.edit),
    path('blogs/<int:number>/delete', views.destroy),
    path('blogs/json', views.json),
]